//
//  ContentView.swift
//  203a38 on 2022/06/09.
//
//  Created by 203a38 on 2022/06/09.
//

import SwiftUI
import MapKit

struct ContentView: View {
    
    @State var myPosition = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: CLLocationDegrees(), longitude: CLLocationDegrees()), span: MKCoordinateSpan())
    
    var body: some View {
        MyMapView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
